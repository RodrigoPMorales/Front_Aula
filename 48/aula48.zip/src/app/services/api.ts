
const API_BASE = "http://localhost:8080/frontmusics/api";

export default API_BASE